<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo 'Sie sind nicht angemeldet! <a href="login.php">[Login]</a>';
    exit;
}
?>
<!DOCTYPE HTML>

<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta charset="utf-8">
    <title>Domgymnasium Naumburg</title>
    <link rel="stylesheet" href="w3-style.css" />
</head>

<body>

    <header class="w3-container w3-indigo w3-center">
        <h1 style="font-weight:bold; font-size:50px; padding: 0; margin: 0;">Domgymnasium Naumburg - intern</h1>
    </header>

    <div class="w3-content">


        <nav class="w3-bar w3-indigo">
            <a href="../login.php?logout" class="w3-bar-item w3-button">Abmelden</a>
            <a href="?do=termine" class="w3-bar-item w3-button">Termine </a>
            <a href="?do=noten10" class="w3-bar-item w3-button">Noten</a>
            <div class="w3-dropdown-hover">
                <button class="w3-button">Wahlbereich</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="?do=kurse" class="w3-bar-item w3-button w3-indigo">Kurse Kursstufe</a><a href="?do=sport10" class="w3-bar-item w3-button w3-indigo">Sportkurse 10</a><a href="?do=projekte" class="w3-bar-item w3-button w3-indigo">Projekte</a>
                </div>
            </div>

            <a href="?do=vplan" class="w3-bar-item w3-button">Vertretungsplan</a>
            <div class="w3-dropdown-hover">
                <button class="w3-button">Kontakte</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="#" class="w3-bar-item w3-button w3-indigo">Schulleitung</a>
                    <a href="#" class="w3-bar-item w3-button w3-indigo">Lehrer</a>
                    <a href="#" class="w3-bar-item w3-button w3-indigo">MitschÃ¼ler</a>
                </div>
            </div>
            <!-- <a href="?do=essen" class="w3-bar-item w3-button">Speiseplan</a> -->
            <a href="http://login.microsoftonline.com" class="w3-bar-item w3-button" target="_blank">Office 365</a>
        </nav>

        <header class="w3-container w3-indigo w3-center">
            <h3 style="font-weight:bold">Noten von Kay Simon 10d</h3>
        </header>
        <br />
        <table border="0" style="width: 100%" class=\"w3-table w3-striped\">
            <tr style="text-align: center" class="w3-indigo">
                <th style=\"text-align:center; width: 100px;\">Fach</th>
                <th>sonstige</th>
                <th style=\"text-align:center; width: 50px;\">%</th>
                <th style=\"text-align:center; width: 50px;\">DS</th>
                <th style=\"text-align:center; width: 50px;\">KA</th>
                <th style=\"text-align:center; width: 50px;\">%</th>
                <th style=\"text-align:center; width: 50px;\">DS</th>
                <th style=\"text-align:center; width: 50px;\">HDS</th>
                <th style=\"text-align:center; width: 50px;\">HNO</th>
                <th style=\"text-align:center; width: 50px;\">EDS</th>
                <th style=\"text-align:center; width: 50px;\">ENO</th>
            </tr>

            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Biologie</th>
                <td style="text-align:center;" class="w3-red">2 1 </td>
                <td style="text-align:center;" class="w3-red">70</td>
                <td style="text-align:center;" class="w3-red">1.05</td>
                <td style="text-align:center;" class="w3-pink">3 </td>
                <td style="text-align:center;" class="w3-pink">30</td>
                <td style="text-align:center;" class="w3-pink">0.90</td>
                <td style="text-align:center;" class="w3-blue">1.95</td>
                <td style="text-align:center;" class="w3-blue">2</td>
                <td style="text-align:center;" class="w3-indigo">1.95</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Chemie</th>
                <td style="text-align:center;" class="w3-red">2 2 2 </td>
                <td style="text-align:center;" class="w3-red">70</td>
                <td style="text-align:center;" class="w3-red">1.40</td>
                <td style="text-align:center;" class="w3-pink">2 </td>
                <td style="text-align:center;" class="w3-pink">30</td>
                <td style="text-align:center;" class="w3-pink">0.60</td>
                <td style="text-align:center;" class="w3-blue">2.00</td>
                <td style="text-align:center;" class="w3-blue">2</td>
                <td style="text-align:center;" class="w3-indigo">2.00</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Deutsch</th>
                <td style="text-align:center;" class="w3-red">3 1 2 </td>
                <td style="text-align:center;" class="w3-red">70</td>
                <td style="text-align:center;" class="w3-red">1.40</td>
                <td style="text-align:center;" class="w3-pink">3 </td>
                <td style="text-align:center;" class="w3-pink">30</td>
                <td style="text-align:center;" class="w3-pink">0.90</td>
                <td style="text-align:center;" class="w3-blue">2.30</td>
                <td style="text-align:center;" class="w3-blue">2</td>
                <td style="text-align:center;" class="w3-indigo">2.30</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Englisch</th>
                <td style="text-align:center;" class="w3-red">3 3 4 </td>
                <td style="text-align:center;" class="w3-red">70</td>
                <td style="text-align:center;" class="w3-red">2.33</td>
                <td style="text-align:center;" class="w3-pink">4 </td>
                <td style="text-align:center;" class="w3-pink">30</td>
                <td style="text-align:center;" class="w3-pink">1.20</td>
                <td style="text-align:center;" class="w3-blue">3.53</td>
                <td style="text-align:center;" class="w3-blue">3</td>
                <td style="text-align:center;" class="w3-indigo">3.53</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Ethik</th>
                <td style="text-align:center;" class="w3-red">2 1 </td>
                <td style="text-align:center;" class="w3-red">100</td>
                <td style="text-align:center;" class="w3-red">1.50</td>
                <td style="text-align:center;" class="w3-pink"></td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-blue">1.50</td>
                <td style="text-align:center;" class="w3-blue">1</td>
                <td style="text-align:center;" class="w3-indigo">1.50</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Geographie</th>
                <td style="text-align:center;" class="w3-red">4 4 1 2 </td>
                <td style="text-align:center;" class="w3-red">100</td>
                <td style="text-align:center;" class="w3-red">2.75</td>
                <td style="text-align:center;" class="w3-pink"></td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-blue">2.75</td>
                <td style="text-align:center;" class="w3-blue">3</td>
                <td style="text-align:center;" class="w3-indigo">2.75</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Geschichte</th>
                <td style="text-align:center;" class="w3-red">3 1 2 </td>
                <td style="text-align:center;" class="w3-red">70</td>
                <td style="text-align:center;" class="w3-red">1.40</td>
                <td style="text-align:center;" class="w3-pink">3 </td>
                <td style="text-align:center;" class="w3-pink">30</td>
                <td style="text-align:center;" class="w3-pink">0.90</td>
                <td style="text-align:center;" class="w3-blue">2.30</td>
                <td style="text-align:center;" class="w3-blue">2</td>
                <td style="text-align:center;" class="w3-indigo">2.30</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Kunst</th>
                <td style="text-align:center;" class="w3-red">3 3 1 2 </td>
                <td style="text-align:center;" class="w3-red">70</td>
                <td style="text-align:center;" class="w3-red">1.57</td>
                <td style="text-align:center;" class="w3-pink">2 </td>
                <td style="text-align:center;" class="w3-pink">30</td>
                <td style="text-align:center;" class="w3-pink">0.60</td>
                <td style="text-align:center;" class="w3-blue">2.17</td>
                <td style="text-align:center;" class="w3-blue">2</td>
                <td style="text-align:center;" class="w3-indigo">2.17</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Mathematik</th>
                <td style="text-align:center;" class="w3-red">1 1 2 </td>
                <td style="text-align:center;" class="w3-red">65</td>
                <td style="text-align:center;" class="w3-red">0.87</td>
                <td style="text-align:center;" class="w3-pink">1 </td>
                <td style="text-align:center;" class="w3-pink">35</td>
                <td style="text-align:center;" class="w3-pink">0.35</td>
                <td style="text-align:center;" class="w3-blue">1.22</td>
                <td style="text-align:center;" class="w3-blue">1</td>
                <td style="text-align:center;" class="w3-indigo">1.22</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Physik</th>
                <td style="text-align:center;" class="w3-red">1 2 1 </td>
                <td style="text-align:center;" class="w3-red">65</td>
                <td style="text-align:center;" class="w3-red">0.87</td>
                <td style="text-align:center;" class="w3-pink">1 </td>
                <td style="text-align:center;" class="w3-pink">35</td>
                <td style="text-align:center;" class="w3-pink">0.35</td>
                <td style="text-align:center;" class="w3-blue">1.22</td>
                <td style="text-align:center;" class="w3-blue">1</td>
                <td style="text-align:center;" class="w3-indigo">1.22</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Spanisch</th>
                <td style="text-align:center;" class="w3-red">4 3 2 2 </td>
                <td style="text-align:center;" class="w3-red">70</td>
                <td style="text-align:center;" class="w3-red">1.93</td>
                <td style="text-align:center;" class="w3-pink">3 </td>
                <td style="text-align:center;" class="w3-pink">30</td>
                <td style="text-align:center;" class="w3-pink">0.90</td>
                <td style="text-align:center;" class="w3-blue">2.83</td>
                <td style="text-align:center;" class="w3-blue">3</td>
                <td style="text-align:center;" class="w3-indigo">2.83</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Sport</th>
                <td style="text-align:center;" class="w3-red">1 1 1 1 1 1 1 1 </td>
                <td style="text-align:center;" class="w3-red">100</td>
                <td style="text-align:center;" class="w3-red">1.00</td>
                <td style="text-align:center;" class="w3-pink"></td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-blue">1.00</td>
                <td style="text-align:center;" class="w3-blue"></td>
                <td style="text-align:center;" class="w3-indigo">1.00</td>
                <td style="text-align:center;" class="w3-indigo"></td>
            <tr>
                <th style="text-align: left; padding-left: 5px;" class="w3-indigo">Wirtschaft</th>
                <td style="text-align:center;" class="w3-red">2 2 1 </td>
                <td style="text-align:center;" class="w3-red">100</td>
                <td style="text-align:center;" class="w3-red">1.67</td>
                <td style="text-align:center;" class="w3-pink"></td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-pink"> </td>
                <td style="text-align:center;" class="w3-blue">1.67</td>
                <td style="text-align:center;" class="w3-blue">2</td>
                <td style="text-align:center;" class="w3-indigo">1.67</td>
                <td style="text-align:center;" class="w3-indigo"></td>
        </table>


    </div>

    <footer style="margin-top:50px; height:45px; padding:10px;" class="w3-container w3-indigo w3-center">
        Domgymnasium Naumburg Â© 2022
    </footer>
</body>

</html>